# AthenZ UI

Athenz UI is a browser based interface that users and admins use to view and manage domains, roles, policies, services etc.

## License

Copyright 2016 Yahoo Inc.

Licensed under the Apache License, Version 2.0: [http://www.apache.org/licenses/LICENSE-2.0]()
