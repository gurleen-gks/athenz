'use strict';

require('./addDomain.js');
require('./athenzPost.js');

window.athenzScriptsLoaded = true;
